using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class BehaviourScript : MonoBehaviour
{
    public float Move;
    public float Speed;
    // Start is called before the first frame update
    void Start()
    {

    }

    // Update is called once per frame
    void Update()
    {
        if (Input.GetKey(KeyCode.A))
        {
            Move = -1;
        }
        else if (Input.GetKey(KeyCode.D))
        {
            Move = 1;
        }
        else Move = 0;
        //
        transform.Translate(Vector3.right * Speed * Move);
    }
}
