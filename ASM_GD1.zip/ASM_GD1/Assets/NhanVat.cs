using System.Collections;
using System.Collections.Generic;
using TMPro;
using UnityEngine;
using UnityEngine.SceneManagement;

public class NhanVat : MonoBehaviour
{
    public Blood blood;

    public float luongMauHienTai;

    public float luongMauToiDa = 10;

    public TextMeshProUGUI txtScore;

    public int score = 0;
    // Start is called before the first frame update

    private void OnCollisionEnter2D(Collision2D collision)
    {
        if (collision.gameObject.tag == "mushroom")
        {
            luongMauHienTai -= 2;
            blood.updateBlood(luongMauHienTai, luongMauToiDa);
            if (luongMauHienTai < 0)
            {
                animator.SetBool("die", true);
            }
        }
    }
    private void OnTriggerEnter2D(Collider2D other)
    {
        Debug.Log("Trigger vao: " + other.gameObject.tag);

        if (other.gameObject.tag == "coin")
        {
            Destroy(other.gameObject);
            score++;
            txtScore.SetText(score.ToString());

            if (score >= 10)
            {
                SceneManager.LoadScene("Level1");
            }
        }
    }
    private Rigidbody2D rigidbody2D;
    private SpriteRenderer spriteRenderer;
    private Animator animator;

    void Start()
    {
        rigidbody2D = GetComponent<Rigidbody2D>();
        spriteRenderer = GetComponent<SpriteRenderer>();
        animator = GetComponent<Animator>();

        luongMauHienTai = luongMauToiDa;
        blood.updateBlood(luongMauHienTai, luongMauToiDa);

    }

    int jumpCount = 3;
    float movePrefix = 5;

    // Update is called once per frame
    void Update()
    {
        if (Input.GetKeyDown(KeyCode.Space))
        {
            rigidbody2D.AddForce(Vector2.up * movePrefix, ForceMode2D.Impulse);
        }
        else if (Input.GetKeyDown(KeyCode.LeftArrow))
        {
            spriteRenderer.flipX = true;
            rigidbody2D.AddForce(Vector2.left * movePrefix, ForceMode2D.Impulse);

            animator.SetBool("running", true);
            animator.SetBool("idle", false);
        }
        else if (Input.GetKeyDown(KeyCode.RightArrow))
        {
            spriteRenderer.flipX = false;
            rigidbody2D.AddForce(Vector2.right * movePrefix, ForceMode2D.Impulse);

            animator.SetBool("running", true);
            animator.SetBool("idle", false);
        }
    }
    private void setToIdle()
    {
        StartCoroutine(wait(1f));

        animator.SetBool("isRun", false);
        animator.SetBool("isGround", true);
    }

    IEnumerator wait(float timeSeconds)
    {

        yield return new WaitForSeconds(timeSeconds);

    }
}
