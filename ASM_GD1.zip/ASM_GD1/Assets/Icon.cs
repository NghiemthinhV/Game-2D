﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using TMPro;

public class Icon : MonoBehaviour

{
    public GameObject text;

    public TextMeshProUGUI diemText;

    int tong = 0;

    void tinhTong(int score)
    {
        tong += score;
        diemText.text = "Điểm: " + tong;
    }
    // Start is called before the first frame update
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        
    }
}
